Barracuda is a new unusual modern geometric sans serif font with characters and shapes contrasting in width, as close as possible to the basic geometric shapes (circle, square, triangle). The font is designed to break the rules and create a irregularity between the round and sharp shapes. It can be a loud and proud hero or a humble supporting actor, upgrading your lay-outs in no time. Barracuda is available in 3 weights plus matching italics. If you use the font in a project, i would love to see the result - antondarrip@gmail.com 

Support and buy a coffee:
https://paypal.me/antondarrip

Follow:
https://www.behance.net/antondarri